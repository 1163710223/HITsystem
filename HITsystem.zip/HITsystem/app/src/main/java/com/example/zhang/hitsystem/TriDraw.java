package com.example.zhang.hitsystem;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class TriDraw extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tri_draw);
    }
}

