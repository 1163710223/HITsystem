package org.shop.dao;

public interface LoginDao {
     public boolean isLoginSuccessful(String id ,String password);
}
