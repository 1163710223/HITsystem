package org.shop.service;

public interface LoginService {
       public boolean isLoginSuccessful(String id,String password);
}
